<?php
// /config/config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'wtxoeyoq_kenzwheels');
define('DB_PASS', '8JyGGP6VyqqEhU7trfJD');
define('DB_NAME', 'wtxoeyoq_kenzwheels');

define('BASE_URL', 'https://api.intencode.com');
