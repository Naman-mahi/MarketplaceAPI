<?php
require_once(__DIR__ . '/../config/config.php');
require_once(__DIR__ . '/../config/database.php');

// /controllers/ProductController.php
class CommanController
{

    //list of brands
    public function getBrands()
    {
        $connection = getDbConnection();
        $stmt = $connection->prepare("SELECT * FROM brands");
        $stmt->execute();
        $result = $stmt->get_result();
        return ['status' => 200, 'message' => 'Brands fetched successfully', 'data' => $result->fetch_all(MYSQLI_ASSOC)];
    }
}
